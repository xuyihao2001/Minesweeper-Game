package codes;

import javax.swing.*;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Color;
import java.awt.Font;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;

public class Drawings extends JComponent {
	@Override
	protected void paintComponent(Graphics g) {
	    
		Graphics2D g2 = (Graphics2D) g;
		g2.setColor(new Color(255, 0, 0));
		
		g2.setFont(new Font("monospaced", Font.BOLD + Font.ITALIC, 24));
		g2.drawString("This is a string", 0, 0);
		
		Rectangle rect1 = new Rectangle(5, 5, 200, 80);
		g2.fill(rect1);
		
		Color red = new Color(0, 0, 255);
		g2.setColor(red);
		Ellipse2D.Double ellipse1 = new Ellipse2D.Double(100, 100, 50, 20);
		g2.fill(ellipse1);
		
		g2.setColor(Color.CYAN);
		Line2D.Double line1 = new Line2D.Double(500, 150, 100, 50);
		g2.draw(line1);
		
		Point2D.Double point1 = new Point2D.Double(200,  200);
		Point2D.Double point2 = new Point2D.Double(500,  200);
		
		Line2D.Double line2 = new Line2D.Double(point1, point2);
		g2.draw(line2);
	}
}
