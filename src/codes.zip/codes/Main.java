package codes;

import javax.swing.*;
import codes.Board;
import java.awt.*;
import java.awt.event.*;
import java.util.Scanner;

public class Main {
	
	public static void main(String[] args) {
		
		Board board = new Board(20, 10, 50, 25);
		JFrame map = board.new Map(20, 10);
		board.printBoard(20, 10);
		//((Map) map).printMap(20, 30);
		
		map.setSize(1200, 600);
		map.setTitle("Minesweeper");
		map.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		map.setVisible(true);
	}

}
